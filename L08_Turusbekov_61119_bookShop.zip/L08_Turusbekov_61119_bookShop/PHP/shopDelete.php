<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Book</title>
    <link rel="stylesheet" href="../CSS/shopDelete.css"> <!-- Подключение ваших CSS стилей -->
</head>
<body>
    <header>
        <h1>Delete Book</h1>
    </header>
    
    <main>
        <form action="" method="POST">
            <label for="delete">Select a book to delete:</label>
            <select name="delete" id="delete">
                <?php 
                    // Подключение к базе данных
                    $servername = "localhost"; // Имя сервера базы данных
                    $username = "root"; // Имя пользователя базы данных
                    $password = ""; // Пароль пользователя базы данных
                    $database = "bookshop"; // Имя базы данных

                    // Создание подключения к базе данных
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Проверка соединения
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Запрос к базе данных для получения списка книг
                    $sql = "SELECT book_id, title FROM books";
                    $result = $conn->query($sql);

                    // Проверка наличия результатов запроса
                    if ($result->num_rows > 0) {
                        // Вывод каждой книги в качестве опции в выпадающем списке
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['book_id'] . "'>" . $row['title'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No books found</option>";
                    }

                    // Закрытие подключения к базе данных
                    $conn->close();
                ?>
            </select>
            <input type="submit" value="Delete">
        </form>

        <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Подключение к базе данных
                $servername = "localhost"; // Имя сервера базы данных
                $username = "root"; // Имя пользователя базы данных
                $password = ""; // Пароль пользователя базы данных
                $database = "bookshop"; // Имя базы данных

                // Создание подключения к базе данных
                $conn = new mysqli($servername, $username, $password, $database);

                // Проверка соединения
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Получаем ID книги, которую нужно удалить, из формы
                $book_id = $_POST['delete'];

                // Подготовка SQL-запроса для удаления данных из таблицы
                $sql = "DELETE FROM books WHERE book_id = $book_id";

                // Проверка выполнения запроса
                if ($conn->query($sql) === TRUE) {
                    // Вывод сообщения об успешном удалении записи
                    echo "<div class='message'>Book removed successfully</div>";
                } else {
                    // Вывод сообщения об ошибке в случае неудачи
                    echo "Error deleting record: " . $conn->error;
                }

                // Закрытие подключения к базе данных
                $conn->close();
            }
        ?>

        <!-- Сообщение об успешном удалении книги -->
        <div class="message">
            Book removed successfully
        </div>
    </main>
    
    <footer>
        <nav>
            <ul>
                <li><a href="../PHP/ShopStart.php">Main page</a></li>
                <li><a href="../PHP/shopView.php">View books</a></li>
                <li><a href="../PHP/shopAdd.php">Add a book</a></li>
                <li><a href="../PHP/shopDelete.php">Delete a book</a></li>
            </ul>
        </nav>
        <h6>Spring 2024</h6>
    </footer>
</body>
</html>
