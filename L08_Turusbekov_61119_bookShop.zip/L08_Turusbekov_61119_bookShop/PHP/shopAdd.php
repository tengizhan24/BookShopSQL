<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/shopAdd.css">
</head>
<body>
    <header>
        <h1>The Happy Student Bookstore</h1>
        <h3>Welcome to the bookstore</h3>
    </header>
    <article>
        We add books
    </article>
    <form action="../PHP/shopStart3_7.php" method="POST">
    <table>
    <tr>
        <td></td>
        <td>Enter</td>
    </tr>
    <tr>
        <td>Title</td>
        <td><input type="text" name="title"></td>
    </tr>
    <tr>
        <td>Author</td>
        <td><input type="text" name="author"></td>
    </tr>
    <tr>
        <td>Price</td>
        <td><input type="text" name="price" pattern="[0-9]*" title="Please enter only digits"></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" value="Save"></td>
    </tr>
</table>

    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Проверяем, были ли отправлены данные формы методом POST
        $title = $_POST['title'];
        $author = $_POST['author'];
        $price = $_POST['price'];

        // Здесь должен быть код для отправки данных в базу данных

        // Выводим сообщение о добавлении записи
        echo "<div class='message'>Book added successfully:</div>";
        echo "<div>Title: $title</div>";
        echo "<div>Author: $author</div>";
        echo "<div>Price: $price</div>";
    }
    ?>
    <footer>
        <nav>
            <ul>
                <li><a href="../PHP/ShopStart.php">Main page</a></li>
                <li><a href="../PHP/shopView.php">View books</a></li>
                <li><a href="../PHP/shopAdd.php">Add a book</a></li>
                <li><a href="../PHP/shopDelete.php">Delete a book</a></li>
            </ul>
        </nav>
        <h6>Spring 2024</h6>
    </footer>
</body>
</html>
