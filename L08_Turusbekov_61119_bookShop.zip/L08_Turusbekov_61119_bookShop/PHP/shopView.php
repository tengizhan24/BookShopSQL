<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Catalog</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/shopView.css">
</head>
<body>
    <header>
    <h1 class="text-center mb-5">Books Catalog</h1>
    </header>
    <div class="container">
        <div class="row">
            <?php
            // Параметры подключения к базе данных
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "bookshop";

            // Создание подключения к базе данных
            $conn = new mysqli($servername, $username, $password, $database);

            // Проверка соединения
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Запрос к базе данных для получения всех книг
            $sql = "SELECT title, author, price FROM books";
            $result = $conn->query($sql);

            // Проверка наличия результатов запроса
            if ($result->num_rows > 0) {
                // Вывод данных каждой книги
                while ($row = $result->fetch_assoc()) {
                    // Форматирование цены
                    $price = number_format($row["price"], 2);
                    echo "<div class='col-md-6'>
                            <div class='card book'>
                                <div class='card-body'>
                                    <h5 class='card-title'>" . $row["title"] . "</h5>
                                    <h6 class='card-subtitle mb-2 text-muted'>" . $row["author"] . "</h6>
                                    <p class='card-text'>Price: $" . $price . "</p>
                                </div>
                            </div>
                          </div>";
                }
            } else {
                echo "<div class='col-md-12'>
                        <div class='alert alert-warning' role='alert'>No books found</div>
                      </div>";
            }

            // Закрытие подключения к базе данных
            $conn->close();
            ?>
        </div>
    </div>
    <footer>
        <nav>
            <ul>
                <li><a href="../PHP/ShopStart.php">Main page</a></li>
                <li><a href="../PHP/shopView.php">View books</a></li>
                <li><a href="../PHP/shopAdd.php">Add a book</a></li>
                <li><a href="../PHP/shopDelete.php">Delete a book</a></li>
            </ul>
        </nav>
        <h6>Spring 2024</h6>
    </footer>

    <!-- Подключение Bootstrap JS (необязательно, если не используете JS) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
