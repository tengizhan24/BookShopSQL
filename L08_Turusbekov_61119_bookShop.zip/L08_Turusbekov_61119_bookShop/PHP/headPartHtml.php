<?php 
    $headPart = '<title> Turusbekov bookstore</title>'; 
    $headPart = '<meta charset="UTF-8">'; 
    echo "Hello, world!";
?>