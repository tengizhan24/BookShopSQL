<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <title> Store Welcome</title> 
    <meta charset="UTF-8"> 
    <link rel="stylesheet" href="../CSS/style.css">
</head> 
<body>  
    <header> 
        <h1> The Happy Student Bookstore</h1> 
        <h3> Welcome to the bookstore </h3>   
    </header> 
    <article> 
        <div class="image-container">
            <img src="../IMG/01.png" alt=""> 
            <div class="image-text">Read books, read!<br>Read morning and evening!<br>Only during the lecture do not read!</div>
        </div>
    </article> 
    <footer> 
        <nav> 
            <ul> 
                <li><a href="../PHP/ShopStart.php">Main page</a></li> 
                <li><a href="../PHP/shopView.php">View books</a></li> 
                <li><a href="../PHP/shopAdd.php">Add a book</a></li> 
                <li><a href="../PHP/shopDelete.php">Delete a book</a></li> 
            </ul> 
        </nav> 
        <h6>Spring 2024</h6> 
    </footer> 
</body> 
</html>
