<?php  
    $serwer = "localhost"; // Имя сервера базы данных
    $username = "root"; // Имя пользователя базы данных
    $password = ""; // Пароль для доступа к базе данных
    $database = "shop"; // Имя базы данных, с которой вы хотите работать

    // Установка соединения с базой данных
    $conn = new mysqli($serwer, $username, $password, $database); 

    // Проверка соединения
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Выполнение запроса к базе данных
    $query = "SELECT * FROM books"; 
    $rs = $conn->query($query); 

    // Закрытие соединения с базой данных
    $conn->close();  

    // Получение количества строк результата запроса
    $num = $rs->num_rows; 
?>
