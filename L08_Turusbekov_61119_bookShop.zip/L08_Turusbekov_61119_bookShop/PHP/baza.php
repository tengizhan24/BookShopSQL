<?php  
    $username = 'root'; 
    $password = ''; 
    $serwer = 'localhost'; 
    $database = 'shop'; 
?> 