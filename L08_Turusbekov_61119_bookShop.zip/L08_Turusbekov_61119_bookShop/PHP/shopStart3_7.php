<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/shopAdd.css">
</head>
<body>
    <header>
        <h1>The Happy Student Bookstore</h1>
        <h1></h1>
    </header>
    <article>
        New added
    </article>
    <!-- <form action="../PHP/shopStart3_7.php" method="POST">
        <table>
            <tr>
                <td></td>
                <td>Enter</td>
            </tr>
            <tr>
                <td>Title</td>
                <td><input type="text" name="title"></td>
            </tr>
            <tr>
                <td>Author</td>
                <td><input type="text" name="author"></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><input type="text" name="price"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Save"></td>
            </tr>
        </table>
    </form>       -->
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Проверяем, были ли отправлены данные формы методом POST
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];

    // Подключение к базе данных
    $servername = "localhost"; // Имя сервера базы данных
    $username = "root"; // Имя пользователя базы данных
    $password = ""; // Пароль пользователя базы данных
    $database = "bookshop"; // Имя базы данных

    // Создание подключения к базе данных
    $conn = new mysqli($servername, $username, $password, $database);

    // Проверка соединения
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Подготовка SQL-запроса для вставки данных в таблицу
    $sql = "INSERT INTO books (title, author, price) VALUES ('$title', '$author', '$price')";

    // Проверка выполнения запроса
    if ($conn->query($sql) === TRUE) {
        // Вывод сообщения об успешном добавлении записи
        echo "<div class='added-book'>";
        echo "<h4>Book added successfully:</h4>";
        echo "<div><strong>Title:</strong> $title</div>";
        echo "<div><strong>Author:</strong> $author</div>";
        echo "<div><strong>Price:</strong> $price</div>";
        echo "</div>";
    } else {
        // Вывод сообщения об ошибке в случае неудачи
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Закрытие подключения к базе данных
    $conn->close();
}
?>
    <footer>
        <nav>
            <ul>
                <li><a href="../PHP/ShopStart.php">Main page</a></li>
                <li><a href="../PHP/shopView.php">View books</a></li>
                <li><a href="../PHP/shopAdd.php">Add a book</a></li>
                <li><a href="../PHP/shopDelete.php">Delete a book</a></li>
            </ul>
        </nav>
        <h6>Spring 2024</h6>
    </footer>
</body>
</html>
