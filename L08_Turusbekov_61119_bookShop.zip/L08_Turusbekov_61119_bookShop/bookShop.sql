create database bookShop;
create table bookShop.books ( 
book_id integer not null auto_increment unique, 
title varchar(70), 
author varchar(70), 
price double(5,2), 
primary key (book_id)
    ); 
INSERT INTO bookShop.books ( 
    book_id,
    title,
    author,
    price 
) 
VALUES 
(1,'Pro CSS and HTML Design Patterns','Michael Bowers',44.99),
(2,'Pro PayPal E-Commerce','Damon Williams',59.99),
(3,'The Complete Robot','Isaac Asimov',8.95),
(4,'Foundation','Isaac ASimov',8.95),
(5,'Area 7','Matthew Reilly',5.99),
(6,'Term Limits','Vince Flynn',6.99); 